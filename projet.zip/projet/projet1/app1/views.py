from django.shortcuts import render, redirect, get_object_or_404
from .forms import *
from .models import *
from faker import Faker
from django.core.paginator import Paginator,PageNotAnInteger,EmptyPage
#pour login
from django.contrib.auth import login, authenticate
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.db import connection
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import PasswordChangeView, PasswordChangeDoneView
from django.urls import reverse
from django.contrib.auth import update_session_auth_hash

def add_personne(request):
    if request.method == 'POST':
        form = PersonneForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('success')
    else:
        form = PersonneForm()

    return render(request, 'add_personne.html', {'form': form})

def success(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM app1_product WHERE VendeurName LIKE %s",   ('%' + request.session['username'] + '%',))
        count = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM app1_product where category like 'Consumer electronics' and VendeurName LIKE %s",   ('%' + request.session['username'] + '%',))
        count2 = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM app1_product where category like 'Home appliances' and VendeurName LIKE %s",   ('%' + request.session['username'] + '%',))
        count3 = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute("SELECT COUNT(*) FROM app1_product where category like 'Clothing and fashion' and VendeurName LIKE %s",   ('%' + request.session['username'] + '%',))
        count4 = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT COUNT(*) FROM app1_product where category like 'Beauty and personal care' and VendeurName LIKE %s",
            ('%' + request.session['username'] + '%',))
        count5 = cursor.fetchone()[0]
    with connection.cursor() as cursor:
            cursor.execute(
                "SELECT COUNT(*) FROM app1_product where category like 'Health and wellness' and VendeurName LIKE %s",
                ('%' + request.session['username'] + '%',))
            count6 = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT COUNT(*) FROM app1_commande where products  LIKE %s",
            ('%' + request.session['username'] + '%',))
        count7 = cursor.fetchone()[0]
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT COUNT(*) FROM app1_cart JOIN app1_product ON app1_cart.product_id = app1_product.id WHERE app1_product.VendeurName LIKE %s",
            ('%' + request.session['username'] + '%',))
        count8 = cursor.fetchone()[0]
    context = {'count': count, 'count2': count2, 'count3': count3, 'count4': count4, 'count5': count5, 'count6': count6, 'count7': count7, 'count8': count8}
    return render(request, 'Vendeur/success.html', context)


def home(request):
    return render(request, 'HomePage.html')
#la page d'error
def error404(request):
    return render(request, 'error404.html')

# profil vendeur
def ProfilVendeur(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT email, username, password,last_login ,date_joined ,id FROM auth_user WHERE username LIKE %s", ('%' + request.session['username'] + '%',))
        row = cursor.fetchone()
        email = row[0]
        username = row[1]
        password = row[2]
        lastlogin = row[3]
        date_joined= row[4]
        id = row[5]
    context = {'email': email, 'username': username, 'password': password,'lastlogin':lastlogin,'date_joined':date_joined,'id':id}
    return render(request, 'Vendeur/profil.html', context)

# profil acheteur
def ProfilAcheteur(request):
    with connection.cursor() as cursor:
        cursor.execute("SELECT email, username, password,last_login ,date_joined ,id FROM auth_user WHERE username LIKE %s", ('%' + request.session['username'] + '%',))
        row = cursor.fetchone()
        email = row[0]
        username = row[1]
        password = row[2]
        lastlogin = row[3]
        date_joined= row[4]
        id = row[5]
    context = {'email': email, 'username': username, 'password': password,'lastlogin':lastlogin,'date_joined':date_joined,'id':id}
    return render(request, 'Acheteur/profil.html', context)


def all(request):
    personnes = Personne.all()
    paginator =Paginator(personnes,5)
    page=request.GET.get('page',1)
    try :
       personne= paginator.page(page)
    except PageNotAnInteger:
        personne = paginator.page(1)
    except EmptyPage:
        personne = paginator.page(paginator.num_pages)
    return render(request, 'all.html', {'personnes': personne})


def update(request,id):
        personne=get_object_or_404(Personne,pk=id)
        if request.method=='POST':
            form=PersonneForm(request.POST,instance=Personne)
            if form.is_valid():
                form.save()
                return redirect('all')
        else:
            form=PersonneForm(instance=personne)
        return render(request,'update.html',{'form':form,'personne':personne})


def delete(request, id):
     personne = get_object_or_404(Personne, pk=id)
     personne.delete()
     return redirect('all')

def search(request):
    query=request.GET.get('keyword')
    personne=Personne.objects.filter(name__contains = query)
    return render(request,'all.html',{'personnes':personne})

def searchProductVendeur(request):
    query = request.GET.get('SearchProductVendeur')
    products = Product.objects.filter(id__contains=query)
    return render(request, 'Vendeur/product_list.html', {'products': products})

def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm()
    return render(request, 'Vendeur/add_product.html', {'form': form})

def updateProduct(request, pk):
    product=get_object_or_404(Product,pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES,instance=product)
        if form.is_valid():
            form.save()
            return redirect('product_list')
    else:
        form = ProductForm(instance=product)
    return render(request, 'Vendeur/updateProduct.html', {'form': form})


def deleteProduct(request, id):
    product= get_object_or_404(Product, pk=id)
    product.delete()
    return redirect('product_list')

@login_required
def product_list(request):
    products = Product.objects.all()
    return render(request, 'Vendeur/product_list.html', {'products': products})

def unpaid(request):
    carts = Cart.objects.all()
    return render(request, 'Vendeur/Unpaid.html', {'carts': carts})

def commandes(request):
    with connection.cursor() as cursor:
        cursor.execute(
            "SELECT date, totalC, user, products, livraison FROM app1_commande WHERE products LIKE %s ",
            ('%' + request.session['username'] + '%',)
        )
        row = cursor.fetchone()
        if row:
            date = row[0]
            totalC = row[1]
            user = row[2]
            livraison = row[3]
            context = {'date': date, 'totalC': totalC, 'user': user, 'livraison': livraison}
            return render(request, 'Vendeur/commandes.html', context)
        else:
            context = {'user': "None."}
            return render(request, 'Vendeur/commandes.html', context)


def register_request(request):
    if request.method == "POST":
        form = NewUserForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful.")
            # pour session
            request.session['username'] = user.username
            return redirect("login")
        else:
            messages.error(request, "Unsuccessful registration. Invalid information.")
    else:
        form = NewUserForm()
    return render(request=request, template_name="Vendeur/signup.html", context={"register_form": form})


def login_request(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                #pour session
                request.session['username'] = user.username
                return redirect("success")
            else:
                messages.error(request,"Invalid username or password.")
        else:
            messages.error(request,"Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="Vendeur/login.html", context={"login_form":form})

def logout(request):
	messages.info(request, "You have successfully logged out.")
	return redirect("login")

def logoutAcheteur(request):
	messages.info(request, "You have successfully logged out.")
	return redirect("Acheteurlogin")


def product_list_acheteur(request):
    products = Product.objects.all()
    paginator = Paginator(products, 5)
    page = request.GET.get('page', 1)
    try:
        product = paginator.page(page)
    except PageNotAnInteger:
        product = paginator.page(1)
    except EmptyPage:
        product = paginator.page(paginator.num_pages)
    return render(request, 'Acheteur/Catalogue.html', {'products': product})


def add_to_cart(request, product_id):
    #avoir le user et le produit
    user = request.user
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        # avoir la quantité choisit
        quantity = int(request.POST.get('quantity_c'))
        if quantity > product.quantity:
            message ="The quantity you have chosen exceeds our stock. So we provide you with "+str(product.quantity)+ " units for "+ str(product.name)
            messages.warning(request, message)
        # creation du cart
        cart_item = Cart(user=user, product=product, quantity_c=quantity)
        cart_item.save()
        # Redirect to the success page
        return redirect('mycart')
def add_commande(request):
    if request.method == 'POST':
        user = request.POST.get('user')
        totalC = request.POST.get('totalC')
        products = request.POST.get('products')
        livraison = request.POST.get('livraison')
        cmd_item = Commande(user=user, totalC=totalC,products=products,livraison=livraison)
        cmd_item.save()
        # modifier la quantité du produit dans la base de donnée
        carts = Cart.objects.filter(user__username=user)
        for cart in carts:
            product = cart.product
            product.quantity -= cart.quantity_c
            product.save()
        # Clear the cart for the user
        carts.delete()
        return redirect('mycart')

def mycart(request):
    user = request.user
    carts = Cart.objects.filter(user=user)
    cart_total = Cart.cart_total(user)
    return render(request, 'Acheteur/MyCart.html', {'carts': carts, 'cart_total': cart_total})

def deleteCart(request, id):
    cart= get_object_or_404(Cart,pk=id)
    cart.delete()
    return redirect('mycart')


def deleteOrder(request, id):
    cart= get_object_or_404(Cart,pk=id)
    cart.delete()
    return redirect('cart')

def updateCart(request, pk):
    # Get the user and cart item
    user = request.user
    cart_item = get_object_or_404(Cart, pk=pk)
    # Check if the request is a POST request
    if request.method == 'POST':
        # Get the quantity from the form
        quantity = int(request.POST.get('quantity_c'))
        # Update the cart item quantity
        cart_item.quantity_c = quantity
        cart_item.save()
        # Redirect to the success page
        return redirect('mycart')
    else:
        # Render the form for updating the cart item quantity
        form = CartForm(instance=cart_item)
        return render(request, 'Acheteur/UpdateCart.html', {'form': form})


def Home_appliances(request):
    products = Product.objects.all()
    paginator = Paginator(products,5)
    page = request.GET.get('page', 1)
    try:
        product = paginator.page(page)
    except PageNotAnInteger:
        product = paginator.page(1)
    except EmptyPage:
        product = paginator.page(paginator.num_pages)
    return render(request, 'Acheteur/Homeappliances.html', {'products': product})


def Consumer_electronics (request):
    products = Product.objects.all()
    return render(request, 'Acheteur/Consumer_electronics.html', {'products': products})

def Clothing_and_fashion (request):
    products = Product.objects.all()
    return render(request, 'Acheteur/Clothing_and_fashion.html', {'products': products})

def Beauty_and_personal_care (request):
    products = Product.objects.all()
    return render(request, 'Acheteur/Beauty_and_personal_care.html', {'products': products})

def Health_and_wellness (request):
    products = Product.objects.all()
    return render(request, 'Acheteur/Health_and_wellness.html', {'products': products})


def user_login(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}.")
                # pour session
                request.session['username'] = user.username
                return redirect("product_list_acheteur")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = AuthenticationForm()
    return render(request=request, template_name="Acheteur/login.html", context={"login_form": form})

def user_register(request):
    if request.method == "POST":
        form = LoginForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful.")
            # pour session
            request.session['username'] = user.username
            return redirect("Acheteurlogin")
        else:
            messages.error(request, "Unsuccessful registration. Invalid information.")
    else:
        form = LoginForm()
    return render(request=request, template_name="Acheteur/registration.html", context={"register_form": form})


@login_required
def password_change(request):
    if request.method == 'POST':
        form = CustomPasswordChangeForm(user=request.user, data=request.POST)
        if form.is_valid():
            form.save()
            update_session_auth_hash(request, form.user)
            return redirect('password_change_done')
    else:
        form = CustomPasswordChangeForm(user=request.user)
    return render(request, 'Acheteur/password_change_form.html', {'form': form})


def password_change_done(request):
    messages.success(request, "Connect using you new password")
    return redirect('home')

def searchProductAcheteur(request):
    query = request.GET.get('searchProductAcheteur')
    products = Product.objects.filter(name__contains=query)
    return render(request, 'Acheteur/Catalogue.html', {'products': products})

def cart(request):
    carts = Cart.objects.all()
    return render(request, 'Vendeur/orders.html', {'carts': carts})
