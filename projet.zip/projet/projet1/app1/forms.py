from django import forms
from .models import *
#ces import pour login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib.auth.views import PasswordChangeView,PasswordChangeDoneView
from django.urls import reverse_lazy
from django.contrib.auth.forms import PasswordChangeForm

#pour changer le mot de passe
class CustomPasswordChangeForm(PasswordChangeForm):
    pass

class PersonneForm(forms.ModelForm):
    class Meta:
        model = Personne
        fields = ['name','email','lastname']

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['VendeurName','name', 'description', 'image','category','price','city','quantity']
        widgets = {
            'category': forms.Select(attrs={'class': 'form-control'}),
            'city': forms.Select(attrs={'class': 'form-control'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'style': 'width:50%;'}),

        }
#form vendeur
class NewUserForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")

    def save(self, commit=True):
        user = super(NewUserForm, self).save(commit=False)
        user.email = self.cleaned_data['email']
        if commit:
            user.save()
        return user



class LoginForm(UserCreationForm):
    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")
    def save(self, commit=True):
        user = super(LoginForm, self).save(commit=False)
        user.username = self.cleaned_data['username']
        if commit:
            user.save()
        return user



class CartForm(forms.ModelForm):
    class Meta:
        model = Cart
        fields = ('quantity_c',)
        widgets = {
            'quantity_c': forms.NumberInput(attrs={'class': 'form-control', 'min': '1'}),
        }
