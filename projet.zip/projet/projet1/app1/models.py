from django.db import models
from django.core.exceptions import ValidationError
from django.db import connection
from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from datetime import date

class Personne(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(default='')
    lastname = models.CharField(default='',max_length=100)
    @staticmethod
    def all():
        return Personne.objects.all()

class Product(models.Model):
    VendeurName = models.CharField(max_length=255,default='None')
    name = models.CharField(max_length=255)
    description =  models.CharField(max_length=2555,default='None')
    image = models.ImageField()
    CATEGORY = (
        ('None', 'None'),
        ('Consumer electronics', 'Consumer electronics'),
        ('Home appliances', 'Home appliances'),
        ('Clothing and fashion', 'Clothing and fashion'),
        ('Beauty and personal care', 'Beauty and personal care'),
        ('Health and wellness', 'Health and wellness'),
    )
    category = models.CharField(max_length=30, choices=CATEGORY, default='None')
    price = models.IntegerField(default=1)
    CITY = (
        ('Agadir', 'Agadir'),
        ('Al Hoceima', 'Al Hoceima'),
        ('Casablanca', 'Casablanca'),
        ('Dakhla', 'Dakhla'),
        ('El Jadida', 'El Jadida'),
        ('Essaouira', 'Essaouira'),
        ('Fes', 'Fes'),
        ('Kenitra', 'Kenitra'),
        ('Khouribga', 'Khouribga'),
        ('Laayoune', 'Laayoune'),
        ('Marrakech', 'Marrakech'),
        ('Meknes', 'Meknes'),
        ('Mohammedia', 'Mohammedia'),
        ('Nador', 'Nador'),
        ('Ouarzazate', 'Ouarzazate'),
        ('Oujda', 'Oujda'),
        ('Rabat', 'Rabat'),
        ('Safi', 'Safi'),
        ('Tangier', 'Tangier'),
        ('Taza', 'Taza')
    )
    city = models.CharField(max_length=30, choices=CITY, default='Marrakech')
    quantity = models.IntegerField(default=1)

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity_c = models.PositiveIntegerField(default=1)
    total = models.PositiveIntegerField(default=1)

    def total(self):
        return self.product.price * self.quantity_c

    @staticmethod
    def cart_total(user):
        return sum(cart.total() for cart in Cart.objects.filter(user=user))

class Commande(models.Model):
    user = models.CharField(max_length=255,default='none')
    totalC =models.PositiveIntegerField(default=1)
    date = models.DateField(default=date.today)
    products = models.TextField()
    livraison = models.CharField(max_length=255, default='none')
