from django.contrib import admin
from .models import *
# Register your models here.
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    search_fields = ('name',)
    #si je veux afficher que le nom et la category
    list_display = ('name','category')
    list_filter = ('category',)
    #pour soter
    ordering = ('name',)