"""projet1 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings
from app1.views import *
#pour login
from app1.forms import NewUserForm
from django.contrib.auth import login
from django.contrib import messages


urlpatterns = [
    path('admin/', admin.site.urls),
    path('add_personne/', add_personne, name='add_personne'),
    path('success/', success, name='success'),
    path('search/', search, name='search'),
    path('searchProductVendeur/', searchProductVendeur, name='searchProductVendeur'),
    path('searchProductAcheteur/', searchProductAcheteur, name='searchProductAcheteur'),
    path('update/<int:id>/', update, name="update"),
    path('delete/<int:id>/', delete, name="delete"),
    path('all/', all, name='all'),
    path('add_product/', add_product, name='add_product'),
    path('ProfilVendeur/', ProfilVendeur, name='ProfilVendeur'),
    path('ProfilAcheteur/', ProfilAcheteur, name='ProfilAcheteur'),
    path('product_list/', product_list, name='product_list'),
    path('unpaid/', unpaid, name='unpaid'),
    path('commandes/', commandes, name='commandes'),
    path('mycart/', mycart, name='mycart'),
    path('cart/', cart, name='cart'),
    path('deleteCart/<int:id>/', deleteCart, name='deleteCart'),
    path('deleteOrder/<int:id>/', deleteOrder, name='deleteOrder'),
    path('product_list_acheteur/', product_list_acheteur, name='product_list_acheteur'),
    path('Home_appliances/', Home_appliances, name='Home_appliances'),
    path('Consumer_electronics/', Consumer_electronics, name='Consumer_electronics'),
    path('Clothing_and_fashion/', Clothing_and_fashion, name='Clothing_and_fashion'),
    path('Beauty_and_personal_care/', Beauty_and_personal_care, name='Beauty_and_personal_care'),
    path('Health_and_wellness/', Health_and_wellness, name='Health_and_wellness'),
    path('add_to_cart/<int:product_id>/', add_to_cart, name='add_to_cart'),
    path('add_commande', add_commande, name='add_commande'),
    path('updateProduct/<int:pk>', updateProduct, name='updateProduct'),
    path('updateCart/<int:pk>', updateCart, name='updateCart'),
    path('deleteProduct/<int:id>/', deleteProduct, name="deleteProduct"),
    path("register", register_request, name="register"),
    path("login", login_request, name="login"),
    path("Acheteurlogin", user_login, name="Acheteurlogin"),
    path("AcheteurRegister",user_register, name="AcheteurRegister"),
    path("logout", logout, name="logout"),
    path("logoutAcheteur", logoutAcheteur, name="logoutAcheteur"),
    path("password_change", password_change, name="password_change"),
    path("password_change_done", password_change_done, name="password_change_done"),
    path("error404/", error404, name="error404"),
    path("", home, name="home")
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)